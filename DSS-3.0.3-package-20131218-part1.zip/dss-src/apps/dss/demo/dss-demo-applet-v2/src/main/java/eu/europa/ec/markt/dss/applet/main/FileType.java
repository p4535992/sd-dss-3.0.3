package eu.europa.ec.markt.dss.applet.main;

/**
 * Filetype supported by the application.
 * 
 * 
 * @version $Revision: 946 $ - $Date: 2011-06-06 17:15:14 +0200 (Mon, 06 Jun 2011) $
 */

public enum FileType {

    XML, PDF, CMS, BINARY, ASiCS;

}
