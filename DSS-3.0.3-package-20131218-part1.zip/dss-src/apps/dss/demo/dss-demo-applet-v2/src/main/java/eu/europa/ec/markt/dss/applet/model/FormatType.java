package eu.europa.ec.markt.dss.applet.model;

public interface FormatType {
    public static final String CADES = "CAdES";
    public static final String XADES = "XAdES";
    public static final String PADES = "PAdES";
    public static final String ASICS = "ASiC-S";

}
